# Directory: RISCV_MS

## Content
- **_ESL_**: SystemC-PPA description
- **_RTL_**: RTL Design of the RISC-V Processor as well as Test Benches and Properties.
- **_CMakeLists.txt_**: 
