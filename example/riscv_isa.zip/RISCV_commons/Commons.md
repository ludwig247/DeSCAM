# RISCV Commons

The folder RISCV_commons specifies files that are mostly shared among all RISCV implementations.
Especially, the memory interfaces are common to all implementations. 

Utilities.h contains some useful functions.  