//
// Created by ludwig on 08.08.18.
//

#ifndef PROJECT_MASTER_H
#define PROJECT_MASTER_H

#include "systemc.h"
#include "Interfaces.h"
#include "Types.h"

class Master: public sc_module{
public:
    SC_CTOR(Master):
    nextsection(setup){SC_THREAD(fsm)};
    enum Sections  {setup,idle,write,read, addr_phase,stop_phase};
    Sections section,nextsection;

    //Communcation from bus
    blocking_in<req_t> request_in;
    blocking_in<bool> ack_in;
    blocking_in<int> data_from_bus;

    //Communication to bus
    blocking_out<req_t> req_to_bus;
    blocking_out<int> data_to_bus;
    blocking_out<bool> ack_out;
    blocking_out<status_t> status_out;


    //Communication with outside
    shared_out<int> data_out;
    shared_in<int> data_in;
    shared_in<int> device_id_in;



    status_t status;
    req_t req;
    //req_t req;
    int data;
    int device_addr;
    bool ack;

    /* Notes:
     * 1) For now no arbirtration, because we only consider single master systems
     * 2) General call addresses are not implemented
     * 3)
     */
    void fsm() {
        while (true) {
            section = nextsection;
            if (section == setup) {
                //Setting the devide id (init through constructor not possible, yet)
                device_id_in->get(device_addr);
                std::cout << "Master device: " << device_addr << std::endl;
                nextsection = idle;
            } else if (section == idle) {
                //Wait for new request from a controller
                //Until then master stays in idle
                request_in->read(req);
                //Received condition
                nextsection = addr_phase;
                /*Unrolling the protocol:
                 * 1) Send start
                 * 2) Send slave addr + rw
                 * 3) Read ack
                 * 4) depending on read/write send our receive data
                 * 5) Either continue with next package or stop
                 */
                //Send start:
                status_out->write(start);
            } else if (section == addr_phase) {
                //Send addr + rw
                /*Using just an integer to send addr+rw requires to construct the byte with bitwise operations here.
                It is easier to send the struct and leave the shifting to to refinment of the macros*/
                req_to_bus->write(req);
                //Read ack from slave
                ack_in->read(ack);
                //Target me? read or write?
                if (req.read) nextsection = read;
                else nextsection = write;

            } else if (section == write) {
                //Write the data to the bus
                data_in->get(data);
                data_to_bus->write(data);
                //Get ACK from master
                ack_in->read(ack);
                //FIXME: how much data? what happens if slave is full ?
                //Write the data to the bus
                data_in->get(data);
                data_to_bus->write(data);
                //Get ACK from master
                ack_in->read(ack);
                nextsection = stop_phase;

            } else if (section == read) {
                //Read data byte from bus
                data_from_bus->read(data);
                data_out->set(data);
                ack_out->write(true);
                //FIXME: how much data? what happens if slave runs out of data?
                data_from_bus->read(data);
                data_out->set(data);
                ack_out->write(false);
                status_out->write(stop);

                nextsection = stop_phase;

            } else if( section = stop_phase){
                //If there is already a new request: continue execution else go back to idle
                if(request_in->nb_read(req)){
                    status_out->write(start);
                    nextsection = addr_phase;
                }else nextsection = idle;
            }
        }
    }
};

#endif //PROJECT_SLAVE_H
