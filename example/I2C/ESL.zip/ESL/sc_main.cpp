//
// Created by ludwig on 04.07.17.
//

#include "systemc.h"
#include "Environment.h"

#include "Master.h"
#include "Slave.h"

int sc_main(int, char **) {
    Slave slave("slave");
    Master master("master");
    Environment environment("environment");

    //Communcation from bus
    Blocking<req_t> request("request");
    environment.request_out(request);
    master.request_in(request);


    Blocking<bool> ack_master_to_slave("ack_master_to_slave");
    master.ack_out(ack_master_to_slave);
    slave.ack_in(ack_master_to_slave);

    Blocking<bool> ack_slave_to_master("ack_slave_to_master");
    slave.ack_out(ack_slave_to_master);
    master.ack_in(ack_slave_to_master);


    Blocking<int> data_master_to_slave("data_master_to_slave");
    master.data_to_bus(data_master_to_slave);
    slave.data_from_bus(data_master_to_slave);

    Blocking<int> data_slave_to_master("data_slave_to_master");
    master.data_from_bus(data_slave_to_master);
    slave.data_to_bus(data_slave_to_master);

    Blocking<req_t> req_master_to_slave("req_master_to_slave");
    master.req_to_bus(req_master_to_slave);
    slave.req_from_bus(req_master_to_slave);

    Blocking<status_t> status("status");
    master.status_out(status);
    slave.status_in(status);


    Shared<int> data1("data1");
    slave.data_out(data1);
    master.data_in(data1);

    Shared<int> data2("data2");
    slave.data_in(data2);
    master.data_out(data2);


    Shared<int> device_id_master("device_id_master");
    environment.id_m(device_id_master);
    master.device_id_in(device_id_master);

    Shared<int> device_id_slave("device_id_slave");
    environment.id_s(device_id_slave);
    slave.device_id_in(device_id_slave);

    sc_start();

}