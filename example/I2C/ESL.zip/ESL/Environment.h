//
// Created by ludwig on 04.01.19.
//

#ifndef PROJECT_ENVIRONMENT_H
#define PROJECT_ENVIRONMENT_H

#include <Interfaces.h>
#include "systemc.h"
#include "Types.h"

class Environment: public sc_module {
public:
    SC_CTOR(Environment){
        SC_METHOD(fsm);
        SC_THREAD(case1);
    };

    shared_out<int> id_m;
    shared_out<int> id_s;
    blocking_out<req_t> request_out;
    req_t req;

    void fsm() {
            id_m->set(4711);
            id_s->set(1337);
            std::cout << "IDS SET" << std::endl;
    }

    void case1(){
        std::cout << "CASE1: START" << std::endl;
        req.read = true;
        req.addr = 1337;
        request_out->write(req);
        wait(SC_ZERO_TIME);
        std::cout << "CASE1: DONE" << std::endl;
    }
};
#endif //PROJECT_ENVIRONMENT_H
