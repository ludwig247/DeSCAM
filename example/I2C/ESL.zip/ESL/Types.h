//
// Created by ludwig on 04.01.19.
//

#ifndef PROJECT_TYPES_H
#define PROJECT_TYPES_H
enum status_t{none,start,stop};
struct req_t{
    int addr;
    bool read;
};
#endif //PROJECT_TYPES_H
